# SmartResQ - Disaster Management & Urban Resilience

Hackathon prototype focused on the Nagpur disaster-response scenario.

## Problem coverage
This version maps the complete statement into working prototype modules:

1. Flood / heavy-rain alerts
2. Nagpur city live interactive map
3. Blocked-road reporting and status
4. Evacuation planning
5. Safe shelters and capacity
6. Emergency resource allocation
7. Citizen SOS / emergency reporting
8. Fire, medical, flood, road and building-damage reporting
9. Emergency-team coordination and responder status
10. Responder route guidance that considers blocked roads
11. Damage assessment and prioritisation
12. Missing-person / family alerts
13. Shared communication feed across response agencies
14. Admin control room for verification, assignment and resolution
15. Local browser persistence using localStorage

## Map
The project uses Leaflet with OpenStreetMap tiles. The base map is live and can be panned/zoomed across Nagpur. The SmartResQ disaster markers, shelter data, incidents and road status are prototype/demo data stored in the browser.

OpenStreetMap tiles are subject to the OpenStreetMap tile usage policy. The project includes visible attribution. For a large public deployment, use an appropriate hosted tile provider or your own tile infrastructure.

## Run
No build step is required.

### Option A: easiest
Open `index.html` in a modern browser with internet access.

### Option B: local server (recommended)
From the `smartresq` folder:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Important prototype note
Weather, emergency incidents, agency status, shelters, resources and damage records are simulated. Do not present the prototype as connected to government emergency systems unless those integrations are actually implemented.

## Suggested hackathon demo flow
Citizen sees heavy-rain alert -> opens Nagpur live map -> reports flood/SOS -> admin verifies -> responder team is assigned -> blocked roads are considered -> shelter capacity is checked -> resources are allocated -> damage assessment is recorded -> agency update is broadcast -> incident is resolved.


## Updated demo flow
- Public Home page uses `assets/home-hero.jpg` and is separate from the operational Dashboard.
- Login/Register and a demo-account entry are included. Authentication is browser-local for prototype use only.
- The left sidebar no longer shows the Hackathon Prototype note.
- The map page has one visible `Complete Nagpur City Live Map` heading.
- Map search uses OpenStreetMap/Nominatim geocoding and OSRM routing to draw a driving route from the browser's live location to the searched Nagpur destination.
- Live location requires browser permission and works best when the project is served from `localhost` or HTTPS.
- The route feature is a prototype integration. For production use, add a backend, rate limits, secure authentication, official emergency data, and a production routing/geocoding service.

## Hackathon Twist Added: Problem 3 - Resource Allocation
The Resource Allocation module now implements the third challenge directly:

- Affected areas are scored using **severity (35%)**, **population (25%)**, **accessibility risk (15%)**, and **urgency (25%)**.
- Available resources are distributed proportionally to the calculated priority scores.
- The system keeps **10% of each available resource as an emergency reserve** instead of consuming the full inventory.
- The dashboard shows the recommended quantity of each resource for each affected area.
- Applying a plan decreases the live inventory and creates an audit-history entry for every allocation.
- Manual allocation is still available for control-room overrides.
- Allocation data persists in browser localStorage along with the existing SmartResQ prototype data.

### Demo steps for Problem 3
1. Login and open **Resource Allocation** from the sidebar.
2. Click **Generate Intelligent Plan**.
3. Show the area priority scores and the recommended resource distribution.
4. Click **Apply Recommended Distribution**.
5. Show the reduced inventory and the **Allocation History** audit trail.
6. Explain that the algorithm prioritises areas with higher disaster severity, larger affected population, lower accessibility and higher urgency while retaining an emergency reserve.
