const defaultData={
 incidents:[
  {id:'INC-1042',type:'Flood',priority:'High',location:'Sakkardara, Nagpur',details:'Water entering low-lying homes',status:'New',time:'2 min ago'},
  {id:'INC-1038',type:'Road Block',priority:'High',location:'Wardha Road',details:'Road flooded near junction',status:'Verified',time:'11 min ago'},
  {id:'INC-1033',type:'Medical',priority:'Medium',location:'Pratap Nagar',details:'Resident needs assistance',status:'Assigned',time:'18 min ago'},
  {id:'INC-1029',type:'Building Damage',priority:'Low',location:'Sonegaon',details:'Minor structural damage reported',status:'New',time:'31 min ago'}
 ],
 roads:[
  {road:'Wardha Road',area:'Khapri Junction',issue:'Waterlogging',severity:'High',status:'Blocked',updated:'8 min ago',lat:21.115,lon:79.085},
  {road:'Kamptee Road',area:'Kalmana',issue:'Flood debris',severity:'High',status:'Blocked',updated:'14 min ago',lat:21.188,lon:79.115},
  {road:'Katol Road',area:'Manish Nagar',issue:'Reduced visibility',severity:'Medium',status:'Caution',updated:'21 min ago',lat:21.125,lon:79.05},
  {road:'Amravati Road',area:'Wadi',issue:'No obstruction',severity:'Low',status:'Clear',updated:'33 min ago',lat:21.17,lon:78.99},
  {road:'Ring Road',area:'Pratap Nagar',issue:'Waterlogging',severity:'Medium',status:'Caution',updated:'39 min ago',lat:21.128,lon:79.085}
 ],
 shelters:[
  {name:'Municipal School No. 4',area:'Sakkardara',distance:'1.2 km',capacity:150,occupied:87,status:'OPEN',lat:21.124,lon:79.105},
  {name:'Community Hall',area:'Pratap Nagar',distance:'2.4 km',capacity:200,occupied:45,status:'OPEN',lat:21.128,lon:79.075},
  {name:'Ward Office Shelter',area:'Manish Nagar',distance:'3.1 km',capacity:100,occupied:91,status:'LIMITED',lat:21.118,lon:79.075}
 ],
 teams:[
  {name:'Rescue Team 01',area:'Sakkardara',members:6,status:'Available'},
  {name:'Rescue Team 02',area:'Wardha Road',members:5,status:'Dispatched'},
  {name:'Medical Team 01',area:'Pratap Nagar',members:4,status:'Available'},
  {name:'Fire Unit 03',area:'Sonegaon',members:7,status:'Standby'}
 ],
 resources:[
  {name:'Rescue Vehicles',available:7,total:10,unit:'vehicles',priority:'High'},
  {name:'Medical Kits',available:34,total:50,unit:'kits',priority:'High'},
  {name:'Drinking Water',available:420,total:600,unit:'litres',priority:'Medium'},
  {name:'Food Packets',available:280,total:400,unit:'packets',priority:'Medium'},
  {name:'Portable Pumps',available:8,total:12,unit:'pumps',priority:'High'},
  {name:'Emergency Lights',available:21,total:30,unit:'units',priority:'Low'}
 ],
 resourceZones:[
  {area:'Sakkardara',severity:'High',population:500,accessibility:60,urgency:95},
  {area:'Wardha Road',severity:'High',population:300,accessibility:45,urgency:90},
  {area:'Kamptee Road',severity:'High',population:260,accessibility:40,urgency:88},
  {area:'Pratap Nagar',severity:'Medium',population:100,accessibility:80,urgency:65},
  {area:'Sonegaon',severity:'Medium',population:180,accessibility:70,urgency:55},
  {area:'Manish Nagar',severity:'Low',population:150,accessibility:85,urgency:50}
 ],
 allocations:[],
 damage:[
  {id:'DM-301',area:'Sakkardara',type:'Flooded homes',severity:'High',status:'Assessed',note:'Water entering ground-floor homes'},
  {id:'DM-297',area:'Sonegaon',type:'Building damage',severity:'Medium',status:'Pending',note:'Structural inspection requested'},
  {id:'DM-292',area:'Kamptee Road',type:'Road obstruction',severity:'High',status:'Assessed',note:'Debris and waterlogging'}
 ],
 missing:[
  {id:'MP-203',name:'Demo Case: A. Sharma',age:'17',lastSeen:'Pratap Nagar Bus Stop',status:'Searching',contact:'9XXXXXXXXX'},
  {id:'MP-201',name:'Demo Case: R. Patil',age:'42',lastSeen:'Kamptee Road Market',status:'Found',contact:'9XXXXXXXXX'}
 ],
 alerts:[
  {title:'Heavy rain warning',area:'Nagpur City',level:'HIGH',message:'Rainfall threshold crossed in the prototype feed.',time:'Now'},
  {title:'Flood risk',area:'Sakkardara',level:'HIGH',message:'Low-lying colonies require preparedness and evacuation planning.',time:'5 min ago'},
  {title:'Road closure',area:'Wardha Road',level:'ACTIVE',message:'Reported waterlogging is blocking a corridor.',time:'8 min ago'}
 ],
 agencies:[
  {name:'Municipal Response',status:'Coordinating',focus:'Shelters, roads, drainage'},
  {name:'Fire & Rescue',status:'Available',focus:'Flood rescue and fire response'},
  {name:'Medical Response',status:'Available',focus:'First aid and patient transfer'},
  {name:'Police / Traffic',status:'Coordinating',focus:'Traffic diversion and public safety'},
  {name:'Disaster Response',status:'Standby',focus:'Resource and incident coordination'}
 ],
 coordFeed:[
  {time:'09:38',agency:'Municipal Response',message:'Shelter capacity reviewed for Sakkardara.'},
  {time:'09:31',agency:'Fire & Rescue',message:'Rescue Team 02 dispatched toward Wardha Road.'},
  {time:'09:24',agency:'Police / Traffic',message:'Traffic caution requested near flooded junction.'}
 ]
};

const STORAGE_KEY='smartresq_demo_v2';
const AUTH_KEY='smartresq_auth_v1';
let data=loadData();
let mapInstances={};
let mapLayers={};
let routeLayers={};
let userLocation=null;
let currentDestination=null;
let liveMarker=null;
const NAGPUR=[21.1458,79.0882];
const areaViews={city:{center:NAGPUR,zoom:11},sakkardara:{center:[21.124,79.105],zoom:14},pratap:{center:[21.128,79.075],zoom:14},wardha:{center:[21.115,79.085],zoom:14},sonegaon:{center:[21.13,79.07],zoom:14},manish:{center:[21.118,79.075],zoom:14},kamptee:{center:[21.188,79.115],zoom:14}};
function clone(x){return JSON.parse(JSON.stringify(x))}
function loadData(){try{const raw=localStorage.getItem(STORAGE_KEY);return raw?JSON.parse(raw):clone(defaultData)}catch(e){return clone(defaultData)}}
function ensureResourceData(){
  if(!Array.isArray(data.resourceZones)||!data.resourceZones.length)data.resourceZones=clone(defaultData.resourceZones);
  if(!Array.isArray(data.allocations))data.allocations=[];
  if(!Array.isArray(data.resources)||!data.resources.length)data.resources=clone(defaultData.resources);
}
function saveData(){localStorage.setItem(STORAGE_KEY,JSON.stringify(data))}
ensureResourceData();
function esc(v){return String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
function toast(msg){const el=document.getElementById('toast');if(!el)return;el.textContent=msg;el.classList.add('show');clearTimeout(window.__toast);window.__toast=setTimeout(()=>el.classList.remove('show'),2800)}

function getAuth(){try{return JSON.parse(localStorage.getItem(AUTH_KEY)||'null')}catch(e){return null}}
function setAuth(profile){localStorage.setItem(AUTH_KEY,JSON.stringify(profile))}
function openAuth(mode='login'){const overlay=document.getElementById('authOverlay');overlay.classList.remove('hidden');const login=mode==='login';document.getElementById('loginForm').classList.toggle('hidden',!login);document.getElementById('registerForm').classList.toggle('hidden',login);document.getElementById('authTitle').textContent=login?'Login':'Create account';document.getElementById('authSubtitle').textContent=login?'Login to open your SmartResQ dashboard.':'Create a demo citizen account for this browser.';document.getElementById('authSwitchText').textContent=login?"Don't have an account?":'Already have an account?';document.getElementById('authSwitchBtn').textContent=login?'Register':'Login'}
function closeAuth(){document.getElementById('authOverlay').classList.add('hidden')}
function enterApp(profile){setAuth(profile);document.getElementById('publicShell').classList.add('hidden');document.getElementById('appShell').classList.remove('hidden');document.getElementById('profileName').textContent=profile.name||'Citizen';closeAuth();showView('dashboard');toast(`Welcome, ${profile.name||'Citizen'}.`)}
function leaveApp(){localStorage.removeItem(AUTH_KEY);document.getElementById('appShell').classList.add('hidden');document.getElementById('publicShell').classList.remove('hidden');document.getElementById('authOverlay').classList.add('hidden');window.scrollTo({top:0,behavior:'smooth'})}

function showView(view){document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));document.getElementById('view-'+view)?.classList.add('active');document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.view===view));const titles={dashboard:'Command Dashboard',map:'Live Nagpur Map',alerts:'Flood & Heavy-Rain Alerts',emergency:'SOS & Emergency Reporting',evacuation:'Area Evacuation Planner',shelters:'Safe Shelters',roads:'Blocked Road Information',resources:'Emergency Resource Allocation',damage:'Damage Assessment',missing:'Missing Person Alerts',responder:'Responder Center',coordination:'Agency Coordination',admin:'Admin Control Room'};document.getElementById('pageTitle').textContent=titles[view]||'SmartResQ';if(view==='map')initMap('mainMap');if(view==='dashboard')initMap('dashboardMap');if(window.innerWidth<1050)document.getElementById('sidebar').classList.remove('open');window.scrollTo({top:0,behavior:'smooth'})}

document.addEventListener('click',e=>{const nav=e.target.closest('[data-view]');if(nav){e.preventDefault();showView(nav.dataset.view)}});
document.getElementById('menuBtn').addEventListener('click',()=>document.getElementById('sidebar').classList.toggle('open'));
document.getElementById('refreshBtn').addEventListener('click',()=>{renderAll();toast('Operational data refreshed.')});
document.getElementById('profileBtn').addEventListener('click',()=>{const p=getAuth();toast(p?`${p.name} · ${p.email}`:'Citizen prototype profile active.')});
document.getElementById('logoutBtn').addEventListener('click',leaveApp);
document.getElementById('homeLoginBtn').addEventListener('click',()=>openAuth('login'));
document.getElementById('homeRegisterBtn').addEventListener('click',()=>openAuth('register'));
document.getElementById('homeStartBtn').addEventListener('click',()=>openAuth('register'));
document.getElementById('homeDashboardBtn').addEventListener('click',()=>getAuth()?enterApp(getAuth()):openAuth('login'));
document.getElementById('authCloseBtn').addEventListener('click',closeAuth);
document.getElementById('authSwitchBtn').addEventListener('click',()=>openAuth(document.getElementById('loginForm').classList.contains('hidden')?'login':'register'));
document.getElementById('demoLoginBtn').addEventListener('click',()=>enterApp({name:'Demo Citizen',email:'demo@smartresq.local'}));
document.getElementById('loginForm').addEventListener('submit',e=>{e.preventDefault();const email=document.getElementById('loginEmail').value.trim().toLowerCase();const password=document.getElementById('loginPassword').value;let stored=null;try{stored=JSON.parse(localStorage.getItem('smartresq_user')||'null')}catch(_){}if(stored&&stored.email===email&&stored.password===password){enterApp({name:stored.name,email:stored.email});return}toast('Account not found. Use Register or the demo account.')});
document.getElementById('registerForm').addEventListener('submit',e=>{e.preventDefault();const name=document.getElementById('registerName').value.trim();const email=document.getElementById('registerEmail').value.trim().toLowerCase();const password=document.getElementById('registerPassword').value;if(!name||!email||password.length<6){toast('Enter a name, valid email and password of 6+ characters.');return}localStorage.setItem('smartresq_user',JSON.stringify({name,email,password}));enterApp({name,email})});

document.getElementById('emergencyForm').addEventListener('submit',e=>{e.preventDefault();const contact=document.getElementById('emContact').value.trim();const name=document.getElementById('emName').value.trim();const location=document.getElementById('emLocation').value.trim();if(!name||!/^[0-9]{10}$/.test(contact)||!location){toast('Please complete name, 10-digit contact and location.');return}const incident={id:'INC-'+Math.floor(1000+Math.random()*8999),type:document.getElementById('emType').value,priority:document.getElementById('emPriority').value,location,details:document.getElementById('emDetails').value.trim()||'Citizen emergency report',status:'New',time:'just now'};data.incidents.unshift(incident);saveData();e.target.reset();document.getElementById('alertBanner').classList.remove('hidden');document.getElementById('alertBanner').textContent=`🚨 ${incident.id} submitted. Priority: ${incident.priority}.`;renderAll();toast('Emergency report submitted.');showView('dashboard')});
document.getElementById('quickSos').addEventListener('click',()=>{document.getElementById('emPriority').value='High';document.getElementById('emType').value='Other';showView('emergency');toast('SOS form opened with High priority.')});
document.getElementById('locateBtn').addEventListener('click',()=>{if(userLocation){document.getElementById('emLocation').value='Current live location';toast('Live location selected.')}else{getLiveLocation().then(()=>{document.getElementById('emLocation').value='Current live location';toast('Live location selected.')}).catch(()=>toast('Location permission was not granted.'))}});
document.getElementById('findShelterBtn').addEventListener('click',()=>{const s=data.shelters.find(x=>x.status==='OPEN')||data.shelters[0];toast(`${s.name} · ${s.distance} · ${s.capacity-s.occupied} spaces available.`);showView('map');setTimeout(()=>focusMap(s.lat,s.lon,15),120)});
document.getElementById('addRoadBtn').addEventListener('click',()=>{const road=prompt('Enter road name for demo report:');if(!road)return;data.roads.unshift({road,area:'Nagpur',issue:'Citizen reported blockage',severity:'Medium',status:'Blocked',updated:'just now',lat:NAGPUR[0],lon:NAGPUR[1]});saveData();renderAll();toast('Road issue added and mapped.')});
document.getElementById('roadSearch').addEventListener('input',renderRoads);document.getElementById('roadFilter').addEventListener('change',renderRoads);
document.getElementById('missingBtn').addEventListener('click',()=>{const name=prompt('Enter missing person name for demo case:');if(!name)return;data.missing.unshift({id:'MP-'+Math.floor(200+Math.random()*700),name,age:'Not provided',lastSeen:'Demo location',status:'Searching',contact:'Not provided'});saveData();renderAll();toast('Missing-person case created.')});
document.getElementById('routeBtn').addEventListener('click',()=>{document.getElementById('routeCard').classList.add('route-highlight');toast('Route updated: blocked corridors excluded from the prototype route.')});
document.getElementById('routeMapBtn').addEventListener('click',()=>{showView('map');setTimeout(()=>focusMap(21.124,79.105,14),120)});
document.getElementById('fitNagpur').addEventListener('click',()=>fitNagpur());
document.getElementById('mapArea').addEventListener('change',e=>{const v=areaViews[e.target.value];if(v)focusMap(v.center[0],v.center[1],v.zoom)});
document.getElementById('searchRouteBtn').addEventListener('click',buildSearchRoute);
document.getElementById('routeSearch').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();buildSearchRoute()}});
document.getElementById('liveRouteBtn').addEventListener('click',async()=>{try{await getLiveLocation(true);if(currentDestination)await drawRoute(userLocation,currentDestination)}catch(e){setRouteStatus(e.message||'Unable to read your live location.','error')}});
document.getElementById('planEvacBtn').addEventListener('click',()=>{const free=data.shelters.reduce((sum,s)=>sum+Math.max(0,s.capacity-s.occupied),0);document.getElementById('evacCapacity').textContent=free+' spaces';document.getElementById('evacOutput').innerHTML='<h3>Generated evacuation plan</h3><div class="plan-grid"><div><b>Risk zone</b><span>Sakkardara low-lying area</span></div><div><b>Primary shelter</b><span>Municipal School No. 4</span></div><div><b>Secondary shelter</b><span>Community Hall, Pratap Nagar</span></div><div><b>Road rule</b><span>Avoid all roads marked Blocked</span></div></div><div class="demo-callout">Plan generated from prototype incident, road and shelter data.</div>';toast('Evacuation plan generated.')});
document.getElementById('allocateBtn').addEventListener('click',()=>generateAllocationPlan(true));
document.getElementById('generateAllocationBtn')?.addEventListener('click',()=>generateAllocationPlan(false));
document.getElementById('applyAllocationBtn')?.addEventListener('click',applyAllocationPlan);
document.getElementById('clearAllocationHistoryBtn')?.addEventListener('click',()=>{data.allocations=[];saveData();renderAll();toast('Allocation history cleared.')});

document.getElementById('damageBtn').addEventListener('click',()=>{const area=prompt('Enter affected area:');if(!area)return;data.damage.unshift({id:'DM-'+Math.floor(300+Math.random()*600),area,type:'New field assessment',severity:'Medium',status:'Pending',note:'Awaiting field verification'});saveData();renderAll();toast('Damage assessment created.')});
document.getElementById('newAlertBtn').addEventListener('click',()=>{data.alerts.unshift({title:'New heavy-rain alert',area:'Nagpur City',level:'HIGH',message:'Demo alert created by control room.',time:'just now'});saveData();renderAll();toast('Demo alert published.')});
document.getElementById('broadcastBtn').addEventListener('click',()=>{data.coordFeed.unshift({time:new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}),agency:'Control Room',message:'Operational update broadcast to response agencies.'});saveData();renderAll();toast('Coordination update broadcast.')});
document.getElementById('clearDemo').addEventListener('click',()=>{if(confirm('Reset all SmartResQ prototype data?')){data=clone(defaultData);saveData();renderAll();toast('Prototype data reset.')}});
document.addEventListener('click',e=>{const btn=e.target.closest('[data-action]');if(!btn)return;const id=btn.dataset.id,action=btn.dataset.action;const item=data.incidents.find(x=>x.id===id);if(!item)return;if(action==='verify')item.status='Verified';if(action==='assign')item.status='Assigned';if(action==='resolve')item.status='Resolved';saveData();renderAll();toast(`${id} marked ${item.status}.`)});

function setRouteStatus(message,type=''){const el=document.getElementById('routeStatus');el.className='route-status '+type;el.innerHTML=message}
function getLiveLocation(force=false){if(userLocation&&!force)return Promise.resolve(userLocation);return new Promise((resolve,reject)=>{if(!navigator.geolocation){reject(new Error('This browser does not support live location.'));return}setRouteStatus('Requesting your live location...');navigator.geolocation.getCurrentPosition(pos=>{userLocation={lat:pos.coords.latitude,lon:pos.coords.longitude,accuracy:pos.coords.accuracy};showLiveMarker();resolve(userLocation)},err=>{const msg=err.code===1?'Location permission was denied. Please allow location access in the browser.':err.code===2?'Your location could not be determined right now.':'Location request timed out.';reject(new Error(msg))},{enableHighAccuracy:true,timeout:12000,maximumAge:10000})})}
function showLiveMarker(){const map=mapInstances.mainMap||initMap('mainMap');const layer=routeLayers.mainMap;if(!layer||!userLocation)return;if(liveMarker){liveMarker.remove()}const icon=iconMarker('#1f6feb','Live');liveMarker=L.marker([userLocation.lat,userLocation.lon],{icon}).bindPopup('<b>📍 Your live location</b>').addTo(layer);map.setView([userLocation.lat,userLocation.lon],14);map.invalidateSize()}
async function geocodeNagpur(query){const q=query.toLowerCase().includes('nagpur')?query:`${query}, Nagpur, Maharashtra, India`;const url='https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&countrycodes=in&q='+encodeURIComponent(q);const res=await fetch(url,{headers:{'Accept':'application/json','Accept-Language':'en'}});if(!res.ok)throw new Error('Location search is temporarily unavailable.');const results=await res.json();if(!results.length)throw new Error('Location not found. Try a landmark or area name in Nagpur.');return {lat:Number(results[0].lat),lon:Number(results[0].lon),name:results[0].display_name}}
async function drawRoute(from,to){const map=mapInstances.mainMap||initMap('mainMap');const layer=routeLayers.mainMap;if(!layer)throw new Error('Map is still loading. Please try again.');layer.clearLayers();liveMarker=null;const url=`https://router.project-osrm.org/route/v1/driving/${from.lon},${from.lat};${to.lon},${to.lat}?overview=full&geometries=geojson`;const res=await fetch(url);if(!res.ok)throw new Error('Route service is temporarily unavailable.');const json=await res.json();if(json.code!=='Ok'||!json.routes?.length)throw new Error('No driving route was found between these locations.');const route=json.routes[0];const coords=route.geometry.coordinates.map(([lon,lat])=>[lat,lon]);L.polyline(coords,{color:'#1f6feb',weight:6,opacity:.85}).addTo(layer);const startIcon=iconMarker('#1f6feb','Live');const endIcon=iconMarker('#e5484d','Destination');L.marker([from.lat,from.lon],{icon:startIcon}).bindPopup('<b>📍 Live location</b>').addTo(layer);L.marker([to.lat,to.lon],{icon:endIcon}).bindPopup(`<b>📌 ${esc(to.name)}</b>`).addTo(layer);const bounds=L.latLngBounds(coords);map.fitBounds(bounds,{padding:[45,45]});const km=(route.distance/1000).toFixed(1);const min=Math.round(route.duration/60);setRouteStatus(`<b>Route ready:</b> Live location → ${esc(to.name)} · ${km} km · about ${min} min`,'success');currentDestination=to}
async function buildSearchRoute(){const input=document.getElementById('routeSearch').value.trim();if(!input){setRouteStatus('Enter a destination in Nagpur first.','error');return}const btn=document.getElementById('searchRouteBtn');btn.disabled=true;setRouteStatus('Searching the destination and getting your live location...');try{const destination=await geocodeNagpur(input);const live=await getLiveLocation();currentDestination=destination;await drawRoute(live,destination)}catch(err){setRouteStatus(esc(err.message||'Could not build the route.'),'error')}finally{btn.disabled=false}}

function iconMarker(color,label){return L.divIcon({className:'custom-map-marker',html:`<div class="marker-dot" style="--marker:${color}" title="${label}"></div>`,iconSize:[20,20],iconAnchor:[10,10],popupAnchor:[0,-8]})}
function initMap(elId){if(typeof L==='undefined')return null;if(mapInstances[elId]){setTimeout(()=>mapInstances[elId].invalidateSize(),80);return mapInstances[elId]}const map=L.map(elId,{zoomControl:true,preferCanvas:true}).setView(NAGPUR,11);L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors',referrerPolicy:'strict-origin-when-cross-origin'}).addTo(map);mapInstances[elId]=map;mapLayers[elId]=L.layerGroup().addTo(map);routeLayers[elId]=L.layerGroup().addTo(map);setTimeout(()=>{map.invalidateSize();renderMapLayers(elId)},100);return map}
function renderMapLayers(elId){const map=mapInstances[elId];if(!map)return;mapLayers[elId].clearLayers();const layer=mapLayers[elId];data.roads.forEach(r=>{if(!r.lat)return;const c=r.status==='Blocked'?'#e5484d':r.status==='Caution'?'#f59e0b':'#16a36a';L.circleMarker([r.lat,r.lon],{radius:7,color:'#fff',weight:2,fillColor:c,fillOpacity:.95}).bindPopup(`<b>🚧 ${esc(r.road)}</b><br>${esc(r.issue)}<br>Status: ${esc(r.status)}`).addTo(layer)});data.shelters.forEach(s=>{L.marker([s.lat,s.lon],{icon:iconMarker('#16a36a','Shelter')}).bindPopup(`<b>🏠 ${esc(s.name)}</b><br>${esc(s.area)}<br>${s.capacity-s.occupied} spaces available`).addTo(layer)});data.incidents.forEach((i,idx)=>{const coords=incidentCoords(i,idx);const c=i.priority==='High'?'#e5484d':i.priority==='Medium'?'#f59e0b':'#6b5ce7';L.marker(coords,{icon:iconMarker(c,'Incident')}).bindPopup(`<b>🚨 ${esc(i.id)} · ${esc(i.type)}</b><br>${esc(i.location)}<br>Status: ${esc(i.status)}`).addTo(layer)});L.circle([21.132,79.08],{radius:1800,color:'#e5484d',fillColor:'#e5484d',fillOpacity:.08,weight:1}).bindPopup('<b>Demo high-risk zone</b><br>Sakkardara low-lying area').addTo(layer)}
function incidentCoords(i,idx){const known={'Sakkardara, Nagpur':[21.132,79.08],'Wardha Road':[21.115,79.085],'Pratap Nagar':[21.128,79.075],'Sonegaon':[21.13,79.07]};if(known[i.location])return known[i.location];const offsets=[[.01,.01],[-.012,.014],[.014,-.012],[-.008,-.018]];return [NAGPUR[0]+offsets[idx%offsets.length][0],NAGPUR[1]+offsets[idx%offsets.length][1]]}
function focusMap(lat,lon,zoom=14){const map=mapInstances.mainMap||initMap('mainMap');map.setView([lat,lon],zoom);map.invalidateSize()}
function fitNagpur(){const map=mapInstances.mainMap||initMap('mainMap');map.fitBounds([[21.02,78.90],[21.27,79.25]],{padding:[20,20]})}
function resourceSeverityScore(v){return ({High:100,Medium:60,Low:30}[v]||30)}
function calculateZoneScore(z){
  const severity=resourceSeverityScore(z.severity);
  const population=Math.min(100,(Number(z.population)||0)/5);
  const access=Math.max(0,100-(Number(z.accessibility)||0));
  const urgency=Number(z.urgency)||0;
  return Math.round(severity*0.35+population*0.25+access*0.15+urgency*0.25);
}
function buildAllocationPlan(){
  const zones=clone(data.resourceZones).map(z=>({...z,score:calculateZoneScore(z)})).sort((a,b)=>b.score-a.score);
  const totalScore=zones.reduce((s,z)=>s+z.score,0)||1;
  const reserveRate=0.10;
  const plan={createdAt:new Date().toLocaleString(),zones,resources:[],reserveRate};
  data.resources.forEach(r=>{
    const available=Math.max(0,Number(r.available)||0);
    const distributable=Math.floor(available*(1-reserveRate));
    let remaining=distributable;
    const allocations=zones.map(z=>{
      const raw=distributable*(z.score/totalScore);
      return {...z,quantity:Math.floor(raw)};
    });
    let assigned=allocations.reduce((s,x)=>s+x.quantity,0);
    let i=0;
    while(assigned<distributable&&allocations.length){allocations[i%allocations.length].quantity++;assigned++;i++;}
    remaining=available-assigned;
    plan.resources.push({name:r.name,unit:r.unit,available,distributable,assigned,remaining,allocations});
  });
  return plan;
}
let currentAllocationPlan=null;
function generateAllocationPlan(autoApply){
  currentAllocationPlan=buildAllocationPlan();
  renderAllocationPlan(currentAllocationPlan);
  if(autoApply){applyAllocationPlan();return}
  toast('Intelligent allocation plan generated from severity, population, accessibility and urgency.');
}
function renderAllocationPlan(plan){
  const summary=document.getElementById('allocationSummary');
  const table=document.getElementById('allocationTable');
  if(!summary||!table)return;
  summary.innerHTML=plan.zones.map(z=>`<div class="allocation-zone"><div><b>${esc(z.area)}</b><small>${esc(z.severity)} severity · population ${z.population} · access ${z.accessibility}% · urgency ${z.urgency}%</small></div><strong>${z.score}</strong></div>`).join('');
  table.innerHTML=plan.resources.map(r=>`<div class="allocation-resource"><div class="allocation-resource-head"><b>${esc(r.name)}</b><span>${r.assigned}/${r.available} ${esc(r.unit)} allocated · ${r.remaining} reserve</span></div><div class="allocation-bars">${r.allocations.map(a=>`<div class="allocation-bar-row"><span>${esc(a.area)}</span><i><em style="width:${r.distributable?Math.min(100,a.quantity/r.distributable*100):0}%"></em></i><b>${a.quantity}</b></div>`).join('')}</div></div>`).join('');
  document.getElementById('allocationPlanMeta').textContent=`Plan generated ${plan.createdAt} · 10% emergency reserve retained`;
  document.getElementById('applyAllocationBtn').disabled=false;
}
function applyAllocationPlan(){
  if(!currentAllocationPlan)currentAllocationPlan=buildAllocationPlan();
  let changed=false;
  currentAllocationPlan.resources.forEach(pr=>{
    const r=data.resources.find(x=>x.name===pr.name);
    if(!r||pr.assigned<=0)return;
    r.available=Math.max(0,r.available-pr.assigned);
    pr.allocations.filter(a=>a.quantity>0).forEach(a=>{
      data.allocations.unshift({id:'RA-'+Date.now().toString().slice(-7)+'-'+Math.floor(Math.random()*90+10),resource:r.name,unit:r.unit,area:a.area,quantity:a.quantity,score:a.score,reason:`${a.severity} severity, population ${a.population}, accessibility ${a.accessibility}%, urgency ${a.urgency}%`,time:new Date().toLocaleString()});
    });
    changed=true;
  });
  if(!changed){toast('No resources available for allocation.');return}
  currentAllocationPlan=null;saveData();renderAll();toast('Intelligent resource allocation applied. Emergency reserve retained.');
}
function renderAll(){renderStats();renderIncidents();renderMini();renderAlerts();renderShelters();renderRoads();renderResources();renderDamage();renderMissing();renderTeams();renderAgencies();Object.keys(mapInstances).forEach(id=>renderMapLayers(id));if(mapInstances.dashboardMap)setTimeout(()=>mapInstances.dashboardMap.invalidateSize(),80)}

const activeAuth=getAuth();
if(activeAuth){document.getElementById('publicShell').classList.add('hidden');document.getElementById('appShell').classList.remove('hidden');document.getElementById('profileName').textContent=activeAuth.name||'Citizen';showView('dashboard')}

function renderStats(){const stats=[['🚨','Active incidents',data.incidents.filter(x=>x.status!=='Resolved').length,'Incident queue'],['🚧','Blocked roads',data.roads.filter(x=>x.status==='Blocked').length,'Need verification'],['🏠','Open shelters',data.shelters.filter(x=>x.status!=='CLOSED').length,'Capacity monitored'],['🚑','Response teams',data.teams.length,'Teams tracked']];const html=stats.map(s=>`<div class="stat-card"><div class="stat-icon">${s[0]}</div><span>${s[1]}</span><b>${s[2]}</b><small>${s[3]}</small></div>`).join('');document.getElementById('statsGrid').innerHTML=html;document.getElementById('adminStats').innerHTML=html}
function renderIncidents(){document.getElementById('incidentList').innerHTML=data.incidents.slice(0,5).map(i=>`<div class="incident"><div class="incident-top"><b>${esc(i.type)} · ${esc(i.id)}</b><span class="priority ${esc(i.priority)}">${esc(i.priority)}</span></div><small>📍 ${esc(i.location)}</small><small>${esc(i.details)} · ${esc(i.time)}</small></div>`).join('')||'<p class="muted">No incidents.</p>';document.getElementById('adminIncidents').innerHTML=data.incidents.map(i=>`<div class="admin-incident"><div class="row"><b>${esc(i.id)} · ${esc(i.type)}</b><span class="priority ${esc(i.priority)}">${esc(i.priority)}</span></div><small>📍 ${esc(i.location)} · ${esc(i.status)}</small><small>${esc(i.details)}</small><div class="admin-actions">${i.status==='New'?`<button class="primary" data-action="verify" data-id="${esc(i.id)}">Verify</button>`:''}${i.status==='Verified'?`<button class="primary" data-action="assign" data-id="${esc(i.id)}">Assign team</button>`:''}${i.status==='Assigned'?`<button class="primary" data-action="resolve" data-id="${esc(i.id)}">Mark resolved</button>`:''}<button data-view="responder">Open responder</button></div></div>`).join('')}
function renderMini(){document.getElementById('alertList').innerHTML=data.alerts.slice(0,4).map(a=>`<div class="alert-row"><span>🌧️ ${esc(a.title)} · ${esc(a.area)}</span><b class="priority ${a.level==='HIGH'?'High':'Medium'}">${esc(a.level)}</b></div>`).join('');document.getElementById('shelterMini').innerHTML=data.shelters.map(s=>`<div class="mini-row"><span>🏠 ${esc(s.name)}</span><b>${Math.max(0,s.capacity-s.occupied)} free</b></div>`).join('');document.getElementById('teamMini').innerHTML=data.teams.slice(0,3).map(t=>`<div class="mini-row"><span>🚑 ${esc(t.name)}</span><b>${esc(t.status)}</b></div>`).join('')}
function renderAlerts(){document.getElementById('alertCards').innerHTML=data.alerts.map(a=>`<div class="alert-card"><span class="badge ${a.level==='HIGH'?'danger':'info'}">${esc(a.level)}</span><h3>🌧️ ${esc(a.title)}</h3><p><b>Area:</b> ${esc(a.area)}</p><p>${esc(a.message)}</p><small>${esc(a.time)}</small></div>`).join('')}
function renderShelters(){document.getElementById('shelterCards').innerHTML=data.shelters.map(s=>{const pct=Math.min(100,Math.round(s.occupied/s.capacity*100));return `<div class="shelter-card"><span class="badge ${pct>85?'danger':'success'}">${esc(s.status)}</span><h3>🏠 ${esc(s.name)}</h3><p>📍 ${esc(s.area)} · ${esc(s.distance)}</p><div class="capacity"><i style="width:${pct}%"></i></div><div class="shelter-meta"><span>${s.occupied} occupied</span><b>${s.capacity-s.occupied} free</b></div><button class="btn btn-light full-btn shelter-nav" data-lat="${s.lat}" data-lon="${s.lon}">Show on map</button></div>`}).join('')}
document.addEventListener('click',e=>{const b=e.target.closest('.shelter-nav');if(!b)return;showView('map');setTimeout(()=>focusMap(+b.dataset.lat,+b.dataset.lon,15),120)});
function renderRoads(){const q=(document.getElementById('roadSearch').value||'').toLowerCase();const f=document.getElementById('roadFilter').value;const rows=data.roads.filter(r=>(f==='all'||r.status===f)&&(`${r.road} ${r.area} ${r.issue}`.toLowerCase().includes(q)));document.getElementById('roadTable').innerHTML=rows.map(r=>`<tr><td><b>${esc(r.road)}</b></td><td>${esc(r.area)}</td><td>${esc(r.issue)}</td><td>${esc(r.severity)}</td><td><span class="status ${esc(r.status)}">${esc(r.status)}</span></td><td>${esc(r.updated)}</td></tr>`).join('')||'<tr><td colspan="6">No matching road reports.</td></tr>'}
function renderResources(){
  const cards=document.getElementById('resourceCards');
  if(!cards)return;
  cards.innerHTML=data.resources.map(r=>{const pct=Math.round(r.available/r.total*100);return `<div class="resource-card"><span class="badge ${r.priority==='High'?'danger':r.priority==='Medium'?'info':'success'}">${esc(r.priority)} priority</span><h3>▣ ${esc(r.name)}</h3><div class="resource-number">${r.available} <small>/ ${r.total} ${esc(r.unit)}</small></div><div class="capacity"><i style="width:${pct}%"></i></div><p>${pct}% currently available</p><button class="btn btn-light full-btn resource-action">Manual allocate 1</button></div>`}).join('');
  const history=document.getElementById('allocationHistory');
  if(history){history.innerHTML=data.allocations.length?data.allocations.slice(0,12).map(a=>`<div class="history-row"><div><b>${esc(a.quantity)} ${esc(a.unit)} ${esc(a.resource)}</b><small>${esc(a.area)} · score ${esc(a.score)} · ${esc(a.reason)}</small></div><span>${esc(a.time)}</span></div>`).join(''):'<div class="empty-state">No intelligent allocations applied yet. Generate a plan to see decision history.</div>';}
  const totalAvailable=data.resources.reduce((s,r)=>s+r.available,0);
  const totalCapacity=data.resources.reduce((s,r)=>s+r.total,0);
  const usedPct=totalCapacity?Math.round((1-totalAvailable/totalCapacity)*100):0;
  const stat=document.getElementById('allocationUsed');if(stat)stat.textContent=usedPct+'%';
  if(!currentAllocationPlan&&document.getElementById('allocationSummary'))document.getElementById('allocationSummary').innerHTML='<div class="empty-state">Click “Generate Intelligent Plan” to calculate priorities using the four challenge factors.</div>';
}
document.addEventListener('click',e=>{if(!e.target.closest('.resource-action'))return;const card=e.target.closest('.resource-card');const title=card.querySelector('h3').textContent.replace('▣ ','').trim();const r=data.resources.find(x=>x.name===title);if(r&&r.available>0){r.available--;data.allocations.unshift({id:'RA-MAN-'+Date.now(),resource:r.name,unit:r.unit,area:'Manual / Control Room',quantity:1,score:0,reason:'Manual control-room allocation',time:new Date().toLocaleString()});saveData();renderAll();toast(`${r.name}: 1 ${r.unit} manually allocated.`)}else toast(`${title}: no units available.`)});
function renderDamage(){document.getElementById('damageCards').innerHTML=data.damage.map(d=>`<div class="damage-card"><span class="badge ${d.severity==='High'?'danger':d.severity==='Medium'?'info':'success'}">${esc(d.severity)}</span><h3>▥ ${esc(d.type)}</h3><p><b>Case:</b> ${esc(d.id)}</p><p><b>Area:</b> ${esc(d.area)}</p><p><b>Status:</b> ${esc(d.status)}</p><p>${esc(d.note)}</p></div>`).join('')}
function renderMissing(){document.getElementById('missingCards').innerHTML=data.missing.map(m=>`<div class="missing-card"><span class="badge ${m.status==='Found'?'success':'danger'}">${esc(m.status)}</span><h3>👤 ${esc(m.name)}</h3><p><b>Case:</b> ${esc(m.id)}</p><p><b>Age:</b> ${esc(m.age)}</p><p><b>Last seen:</b> ${esc(m.lastSeen)}</p><p><b>Contact:</b> ${esc(m.contact)}</p></div>`).join('')}
function renderTeams(){document.getElementById('teamTable').innerHTML=`<div class="team-list">${data.teams.map(t=>`<div class="team-card"><div><span class="team-icon">🚑</span><div><b>${esc(t.name)}</b><small>${esc(t.area)} · ${t.members} members</small></div></div><span class="badge ${t.status==='Available'?'success':t.status==='Dispatched'?'info':''}">${esc(t.status)}</span></div>`).join('')}</div>`}
function renderAgencies(){document.getElementById('agencyCards').innerHTML=data.agencies.map(a=>`<div class="agency-card"><span class="badge ${a.status==='Available'?'success':a.status==='Standby'?'info':'danger'}">${esc(a.status)}</span><h3>◎ ${esc(a.name)}</h3><p>${esc(a.focus)}</p></div>`).join('');document.getElementById('coordFeed').innerHTML=data.coordFeed.map(x=>`<div class="feed-row"><time>${esc(x.time)}</time><div><b>${esc(x.agency)}</b><p>${esc(x.message)}</p></div></div>`).join('')}

renderAll();
